<?php
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓


//合作身份者id
// $partnerid='10000';

$partnerid='10007';

//安全检验码
// $key='6KCJSwEc8RXR7X352k7iWwz7AmDr';
$key='Z23e8m8N4NXjHsT4EYCPz8HPNh3j';


//服务器 异步通知页面
$no_url='http://pay.7684.org/webbuy/api/php_UTF-8/no_url.php';


// 同步通知页面
$re_url='http://pay.7684.org/webbuy/api/php_UTF-8/re_url.php';



//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

?>